import 'package:kickmind_ai/core/config/kickmind_feature_flags.dart';
import 'package:kickmind_ai/features/matches/data/sources/api_match_data_source.dart';
import 'package:kickmind_ai/features/matches/data/sources/match_data_source.dart';
import 'package:kickmind_ai/features/matches/data/sources/mock_match_data_source.dart';
import 'package:kickmind_ai/features/matches/domain/football_match.dart';
import 'package:kickmind_ai/features/team_stats/data/pro_match_enrichment_service.dart';

/// Sicheres V2-Repository.
///
/// Es ersetzt NICHT automatisch deine alte App-Logik.
/// Du kannst Screens später schrittweise von FootballApiService/MockRepository
/// auf MatchRepositoryV2 umstellen.
class MatchRepositoryV2 {
  MatchRepositoryV2({
    MatchDataSource? apiSource,
    MatchDataSource? mockSource,
    ProMatchEnrichmentService enrichmentService = const ProMatchEnrichmentService(),
  })  : _apiSource = apiSource ?? ApiMatchDataSource(),
        _mockSource = mockSource ?? MockMatchDataSource(),
        _enrichmentService = enrichmentService;

  final MatchDataSource _apiSource;
  final MatchDataSource _mockSource;
  final ProMatchEnrichmentService _enrichmentService;

  Future<List<FootballMatch>> fetchToday({bool forceRefresh = false}) {
    return _load((source) => source.fetchToday(forceRefresh: forceRefresh));
  }

  Future<List<FootballMatch>> fetchTomorrow({bool forceRefresh = false}) {
    return _load((source) => source.fetchTomorrow(forceRefresh: forceRefresh));
  }

  Future<List<FootballMatch>> fetchNext3Days({bool forceRefresh = false}) {
    return _load((source) => source.fetchNext3Days(forceRefresh: forceRefresh));
  }

  Future<List<FootballMatch>> fetchWeek({bool forceRefresh = false}) {
    return _load((source) => source.fetchWeek(forceRefresh: forceRefresh));
  }

  Future<List<FootballMatch>> _load(
      Future<List<FootballMatch>> Function(MatchDataSource source) loader,
      ) async {
    final primary = KickMindFeatureFlags.useRealFixtures ? _apiSource : _mockSource;
    final fallback = KickMindFeatureFlags.useRealFixtures ? _mockSource : _apiSource;

    var matches = <FootballMatch>[];

    try {
      matches = await loader(primary);
    } catch (_) {
      matches = <FootballMatch>[];
    }

    if (matches.isEmpty && !KickMindFeatureFlags.allowEmptyRealResults) {
      try {
        matches = await loader(fallback);
      } catch (_) {
        matches = <FootballMatch>[];
      }
    }

    matches = _deduplicateAndSort(matches);

    if (KickMindFeatureFlags.useProPredictionEnrichment) {
      matches = _enrichmentService.enrichAll(matches);
    }

    return matches.take(KickMindFeatureFlags.maxMatchesPerView).toList();
  }

  List<FootballMatch> _deduplicateAndSort(List<FootballMatch> matches) {
    final map = <String, FootballMatch>{};
    for (final match in matches) {
      map[match.id] = match;
    }

    final result = map.values.toList()
      ..sort((a, b) => a.kickoff.compareTo(b.kickoff));
    return result;
  }
}
