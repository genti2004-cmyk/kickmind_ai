import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:kickmind_ai/features/matches/domain/football_match.dart';

class FootballApiService {
  FootballApiService();

  Future<List<FootballMatch>> fetchTodayFixtures() async {
    try {
      final response = await http.get(
        Uri.parse('https://api.football-data.org/v4/matches'),
        headers: {
          'X-Auth-Token': 'DEIN_API_KEY', // ← ersetzen
        },
      );

      if (response.statusCode != 200) {
        return [];
      }

      final data = json.decode(response.body);

      final List matches = data['matches'] ?? [];

      return matches.map((m) {
        return FootballMatch(
          id: m['id'].toString(),
          league: m['competition']?['name'] ?? 'Liga',
          home: m['homeTeam']?['name'] ?? 'Home',
          away: m['awayTeam']?['name'] ?? 'Away',
          kickoff: DateTime.tryParse(m['utcDate'] ?? '') ?? DateTime.now(),
          aiScore: 70,
          riskLevel: 'Mittel',
          tip: '1X',
          shortReason: 'Basis Analyse',
        );
      }).toList();
    } catch (e) {
      return [];
    }
  }
}