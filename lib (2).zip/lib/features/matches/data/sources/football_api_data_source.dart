import 'package:kickmind_ai/features/matches/domain/football_match.dart';
import 'package:kickmind_ai/features/matches/data/api/football_api_service.dart';

class FootballApiDataSource {
  final FootballApiService _service;

  FootballApiDataSource({FootballApiService? service})
      : _service = service ?? FootballApiService();

  Future<List<FootballMatch>> getTodayMatches() async {
    return await _service.fetchTodayFixtures();
  }
}