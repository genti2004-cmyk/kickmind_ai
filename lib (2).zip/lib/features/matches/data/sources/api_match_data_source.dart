import 'package:kickmind_ai/features/matches/data/api/football_api_service.dart';
import 'package:kickmind_ai/features/matches/data/sources/match_data_source.dart';
import 'package:kickmind_ai/features/matches/domain/football_match.dart';

/// Echte API-Datenquelle.
/// Kapselt FootballApiService, damit UI und Repository nicht direkt an der API hängen.
class ApiMatchDataSource implements MatchDataSource {
  ApiMatchDataSource({FootballApiService? service})
      : _service = service ?? FootballApiService();

  final FootballApiService _service;

  @override
  Future<List<FootballMatch>> fetchToday({bool forceRefresh = false}) {
    return _service.fetchTodayFixtures(forceRefresh: forceRefresh);
  }

  @override
  Future<List<FootballMatch>> fetchTomorrow({bool forceRefresh = false}) {
    return _service.fetchTomorrowFixtures(forceRefresh: forceRefresh);
  }

  @override
  Future<List<FootballMatch>> fetchNext3Days({bool forceRefresh = false}) {
    return _service.fetchNext3DaysFixtures(forceRefresh: forceRefresh);
  }

  @override
  Future<List<FootballMatch>> fetchWeek({bool forceRefresh = false}) {
    return _service.fetchWeekFixtures(forceRefresh: forceRefresh);
  }
}
