import 'package:flutter/material.dart';
import 'package:kickmind_ai/core/theme/kickmind_theme.dart';
import 'package:kickmind_ai/features/matches/domain/football_match.dart';
import 'package:kickmind_ai/features/saved_tips/data/saved_tips_service.dart';

class MatchDetailScreen extends StatefulWidget {
  final FootballMatch match;

  const MatchDetailScreen({super.key, required this.match});

  @override
  State<MatchDetailScreen> createState() => _MatchDetailScreenState();
}

class _MatchDetailScreenState extends State<MatchDetailScreen> {
  final SavedTipsService _savedTipsService = SavedTipsService();
  bool _saved = false;
  bool _loading = true;
  double _stake = 10;

  FootballMatch get match => widget.match;

  @override
  void initState() {
    super.initState();
    _loadSavedState();
  }

  Future<void> _loadSavedState() async {
    final saved = await _savedTipsService.isSaved(match.id);
    if (!mounted) return;
    setState(() {
      _saved = saved;
      _loading = false;
    });
  }

  Future<void> _toggleSaved() async {
    if (_saved) {
      await _savedTipsService.removeTip(match.id);
    } else {
      await _savedTipsService.saveTip(match);
    }
    if (!mounted) return;
    setState(() => _saved = !_saved);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_saved ? 'Tipp gespeichert' : 'Tipp entfernt')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scoreColor = KickMindTheme.scoreColor(match.aiScore);
    final possibleReturn = _stake * match.odds;
    final profit = possibleReturn - _stake;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Match Analyse'),
        actions: [
          IconButton(
            onPressed: _loading ? null : _toggleSaved,
            icon: Icon(_saved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Hero(match: match, scoreColor: scoreColor),
              const SizedBox(height: 16),
              const _SectionTitle('KI Empfehlung'),
              const SizedBox(height: 10),
              _Recommendation(match: match),
              const SizedBox(height: 16),
              const _SectionTitle('Analysewerte'),
              const SizedBox(height: 10),
              _StatsGrid(match: match),
              const SizedBox(height: 16),
              const _SectionTitle('Formvergleich'),
              const SizedBox(height: 10),
              _FormComparison(match: match),
              const SizedBox(height: 16),
              const _SectionTitle('Begründung'),
              const SizedBox(height: 10),
              _PremiumCard(
                child: Text(
                  match.shortReason.isEmpty ? 'Analyse basiert auf Form, Tore-Trend, Risiko und AI-Score.' : match.shortReason,
                  style: TextStyle(color: Colors.grey.shade800, height: 1.45, fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 16),
              const _SectionTitle('Gewinnsimulation'),
              const SizedBox(height: 10),
              _PremiumCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Einsatz: ${_stake.toStringAsFixed(0)} €', style: const TextStyle(fontWeight: FontWeight.w900)),
                    Slider(min: 5, max: 100, divisions: 19, value: _stake, onChanged: (value) => setState(() => _stake = value)),
                    _InfoRow(label: 'Mögliche Auszahlung', value: '${possibleReturn.toStringAsFixed(2)} €'),
                    _InfoRow(label: 'Möglicher Gewinn', value: '${profit.toStringAsFixed(2)} €'),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: _toggleSaved,
                icon: Icon(_saved ? Icons.bookmark_remove_rounded : Icons.bookmark_add_rounded),
                label: Text(_saved ? 'Tipp entfernen' : 'Tipp speichern'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  final FootballMatch match;
  final Color scoreColor;
  const _Hero({required this.match, required this.scoreColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1565C0), Color(0xFF0D47A1)]),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: KickMindTheme.primary.withOpacity(0.22), blurRadius: 18, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(match.league, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(match.teamsLabel, style: const TextStyle(color: Colors.white, fontSize: 22, height: 1.15, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          Row(
            children: [
              const Icon(Icons.schedule_rounded, color: Colors.white70, size: 18),
              const SizedBox(width: 6),
              Text(match.kickoffLabel, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              const Spacer(),
              _Badge(text: 'AI ${match.aiScore}%', color: Colors.white),
            ],
          ),
        ],
      ),
    );
  }
}

class _Recommendation extends StatelessWidget {
  final FootballMatch match;
  const _Recommendation({required this.match});

  @override
  Widget build(BuildContext context) {
    final scoreColor = KickMindTheme.scoreColor(match.aiScore);
    return _PremiumCard(
      child: Row(
        children: [
          Container(
            width: 74,
            height: 74,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: scoreColor.withOpacity(0.12), shape: BoxShape.circle),
            child: Text(match.tipLabel, textAlign: TextAlign.center, style: TextStyle(color: scoreColor, fontSize: 18, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _Badge(text: '${match.riskEmoji} ${match.riskLevel}', color: KickMindTheme.riskColor(match.riskLevel)),
                _Badge(text: 'Quote ${match.odds.toStringAsFixed(2)}', color: Colors.indigo),
                _Badge(text: 'Score ${match.aiScore}/100', color: scoreColor),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatsGrid extends StatelessWidget {
  final FootballMatch match;
  const _StatsGrid({required this.match});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(children: [
          Expanded(child: _StatTile(label: 'Heimform', value: '${match.homeFormScore}', icon: Icons.home_rounded)),
          const SizedBox(width: 10),
          Expanded(child: _StatTile(label: 'Auswärtsform', value: '${match.awayFormScore}', icon: Icons.flight_takeoff_rounded)),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _StatTile(label: 'Tore-Trend', value: '${match.goalsScore}', icon: Icons.sports_soccer_rounded)),
          const SizedBox(width: 10),
          Expanded(child: _StatTile(label: 'Saison', value: '${match.season}', icon: Icons.calendar_month_rounded)),
        ]),
      ],
    );
  }
}

class _FormComparison extends StatelessWidget {
  final FootballMatch match;
  const _FormComparison({required this.match});

  @override
  Widget build(BuildContext context) {
    final total = (match.homeFormScore + match.awayFormScore).clamp(1, 200);
    return _PremiumCard(
      child: Column(
        children: [
          _TeamBar(label: match.homeTeam, value: match.homeFormScore, factor: match.homeFormScore / total, color: KickMindTheme.primary),
          const SizedBox(height: 14),
          _TeamBar(label: match.awayTeam, value: match.awayFormScore, factor: match.awayFormScore / total, color: Colors.deepPurple),
        ],
      ),
    );
  }
}

class _TeamBar extends StatelessWidget {
  final String label;
  final int value;
  final double factor;
  final Color color;
  const _TeamBar({required this.label, required this.value, required this.factor, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900))),
          Text('$value', style: TextStyle(color: color, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: factor.clamp(0.05, 1.0),
            minHeight: 10,
            backgroundColor: color.withOpacity(0.10),
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _StatTile({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return _PremiumCard(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: KickMindTheme.primary, size: 20),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: KickMindTheme.textMuted, fontSize: 12, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [
        Expanded(child: Text(label, style: const TextStyle(color: KickMindTheme.textMuted, fontWeight: FontWeight.w800))),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _PremiumCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const _PremiumCard({required this.child, this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withOpacity(0.04)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 16, offset: const Offset(0, 8))],
      ),
      child: child,
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color color;
  const _Badge({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    final light = color == Colors.white;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: light ? Colors.white.withOpacity(0.16) : color.withOpacity(0.12), borderRadius: BorderRadius.circular(999)),
      child: Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900)),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900));
  }
}
