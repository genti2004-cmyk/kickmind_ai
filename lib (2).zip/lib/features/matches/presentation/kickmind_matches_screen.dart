import 'package:flutter/material.dart';
import 'package:kickmind_ai/core/theme/kickmind_theme.dart';
import 'package:kickmind_ai/features/filters/presentation/filter_screen.dart';
import 'package:kickmind_ai/features/matches/data/repositories/match_repository_impl.dart';
import 'package:kickmind_ai/features/matches/domain/football_match.dart';
import 'package:kickmind_ai/features/matches/domain/match_date_range.dart';
import 'package:kickmind_ai/features/matches/presentation/match_detail_screen.dart';
import 'package:kickmind_ai/features/matches/presentation/match_card.dart';
import 'package:kickmind_ai/features/predictions/domain/prediction_engine.dart';

class KickMindMatchesScreen extends StatefulWidget {
  const KickMindMatchesScreen({super.key});

  @override
  State<KickMindMatchesScreen> createState() => _KickMindMatchesScreenState();
}

class _KickMindMatchesScreenState extends State<KickMindMatchesScreen> {
  final MatchRepositoryImpl _repo = MatchRepositoryImpl();
  final PredictionEngine _engine = const PredictionEngine();

  MatchDateRange _range = MatchDateRange.today;
  FilterResult? _activeFilter;
  late Future<List<FootballMatch>> _future;

  @override
  void initState() {
    super.initState();
    _future = _repo.getMatches(range: _range);
  }

  void _reload() {
    setState(() {
      _future = _repo.getMatches(range: _range);
    });
  }

  void _changeRange(MatchDateRange range) {
    if (_range == range) return;
    setState(() {
      _range = range;
      _future = _repo.getMatches(range: _range);
    });
  }

  Future<void> _openFilter() async {
    final result = await Navigator.push<FilterResult>(
      context,
      MaterialPageRoute(
        builder: (_) => const FilterScreen(),
      ),
    );

    if (!mounted) return;

    if (result != null) {
      setState(() {
        _activeFilter = result;
      });
    }
  }

  void _resetFilter() {
    setState(() {
      _activeFilter = null;
    });
  }

  List<FootballMatch> _applyFilter(List<FootballMatch> matches) {
    final filter = _activeFilter;
    if (filter == null) return matches;

    return matches.where((m) {
      if (filter.league != null && filter.league!.isNotEmpty && m.league != filter.league) {
        return false;
      }

      if (filter.risk != null && filter.risk!.isNotEmpty && m.riskLevel != filter.risk) {
        return false;
      }

      if (m.aiScore < filter.minScore) {
        return false;
      }

      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: KickMindTheme.background,
      appBar: AppBar(
        title: const Text('KickMind AI'),
        actions: [
          IconButton(
            tooltip: 'Filter',
            onPressed: _openFilter,
            icon: const Icon(Icons.filter_alt_rounded),
          ),
          IconButton(
            tooltip: 'Aktualisieren',
            onPressed: _reload,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: FutureBuilder<List<FootballMatch>>(
          future: _future,
          builder: (context, snapshot) {
            final loading = snapshot.connectionState == ConnectionState.waiting;
            final rawMatches = snapshot.data ?? <FootballMatch>[];
            final matches = _applyFilter(rawMatches);
            final topTips = _engine.rankTopTips(matches, limit: 3);
            final proHighlights = matches
                .where((m) => m.aiScore >= 80 && m.riskLevel.toLowerCase() != 'hoch')
                .toList();

            if (loading) {
              return const Center(child: CircularProgressIndicator());
            }

            return RefreshIndicator(
              onRefresh: () async => _reload(),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                children: [
                  _RangeSelector(
                    selected: _range,
                    onChanged: _changeRange,
                  ),
                  const SizedBox(height: 12),

                  if (_activeFilter != null)
                    _ActiveFilterBanner(
                      filter: _activeFilter!,
                      onReset: _resetFilter,
                    ),

                  if (topTips.isNotEmpty) ...[
                    const _SectionHeader(
                      title: '🔥 Top Tipps heute',
                      subtitle: 'Beste AI-Scores aus deiner Auswahl',
                    ),
                    const SizedBox(height: 10),
                    ...topTips.map(
                          (m) => _TopTipMiniCard(
                        match: m,
                        onTap: () => _openDetail(m),
                      ),
                    ),
                    const SizedBox(height: 18),
                  ],

                  if (proHighlights.isNotEmpty) ...[
                    const _SectionHeader(
                      title: '💎 PRO Highlights',
                      subtitle: 'AI ≥ 80 und Risiko nicht hoch',
                    ),
                    const SizedBox(height: 10),
                    ...proHighlights.take(3).map(
                          (m) => _TopTipMiniCard(
                        match: m,
                        pro: true,
                        onTap: () => _openDetail(m),
                      ),
                    ),
                    const SizedBox(height: 18),
                  ],

                  _SectionHeader(
                    title: _range.label,
                    subtitle: '${matches.length} Spiele gefunden',
                  ),
                  const SizedBox(height: 10),

                  if (matches.isEmpty)
                    const _EmptyState()
                  else
                    ...matches.map(
                          (match) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: MatchCard(
                          match: match,
                          onTap: () => _openDetail(match),
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _openDetail(FootballMatch match) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MatchDetailScreen(match: match),
      ),
    );
  }
}

class _RangeSelector extends StatelessWidget {
  final MatchDateRange selected;
  final ValueChanged<MatchDateRange> onChanged;

  const _RangeSelector({
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: MatchDateRange.values.map((range) {
          final active = range == selected;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              selected: active,
              label: Text(range.label),
              onSelected: (_) => onChanged(range),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _ActiveFilterBanner extends StatelessWidget {
  final FilterResult filter;
  final VoidCallback onReset;

  const _ActiveFilterBanner({
    required this.filter,
    required this.onReset,
  });

  @override
  Widget build(BuildContext context) {
    final parts = <String>[
      if (filter.league != null) 'Liga: ${filter.league}',
      if (filter.risk != null) 'Risiko: ${filter.risk}',
      'AI ≥ ${filter.minScore}',
    ];

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: KickMindTheme.warning.withOpacity(0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: KickMindTheme.warning.withOpacity(0.22)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Filter aktiv: ${parts.join(' • ')}',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
          TextButton(
            onPressed: onReset,
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 2),
              Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ],
    );
  }
}

class _TopTipMiniCard extends StatelessWidget {
  final FootballMatch match;
  final VoidCallback onTap;
  final bool pro;

  const _TopTipMiniCard({
    required this.match,
    required this.onTap,
    this.pro = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = KickMindTheme.scoreColor(match.aiScore);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.20)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                '${pro ? '💎 ' : ''}${match.teamsLabel}',
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '${match.tipLabel} • AI ${match.aiScore}',
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: KickMindTheme.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Column(
        children: [
          Icon(Icons.sports_soccer_rounded, size: 42),
          SizedBox(height: 12),
          Text(
            'Keine Spiele gefunden',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
          ),
          SizedBox(height: 6),
          Text(
            'Ändere den Zeitraum oder setze den Filter zurück.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
