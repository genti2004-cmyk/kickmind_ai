import 'package:kickmind_ai/features/matches/domain/football_match.dart';
import 'package:kickmind_ai/features/predictions/domain/prediction_engine.dart';
import 'package:kickmind_ai/features/team_stats/data/mock_team_stats_repository.dart';

/// Pro-Enrichment-Schicht.
///
/// Phase 1: Noch sicher parallel. Kann jederzeit abgeschaltet werden.
/// Nimmt vorhandene Matches und berechnet daraus Pro-Werte über TeamStats/H2H/Tabelle.
class ProMatchEnrichmentService {
  const ProMatchEnrichmentService({
    PredictionEngine engine = const PredictionEngine(),
    MockTeamStatsRepository statsRepository = const MockTeamStatsRepository(),
  })  : _engine = engine,
        _statsRepository = statsRepository;

  final PredictionEngine _engine;
  final MockTeamStatsRepository _statsRepository;

  List<FootballMatch> enrichAll(List<FootballMatch> matches) {
    return matches.map(enrich).toList();
  }

  FootballMatch enrich(FootballMatch match) {
    final input = _statsRepository.buildInput(match);
    return _engine.buildProMatch(input);
  }
}
