import 'package:kickmind_ai/features/matches/domain/football_match.dart';

class PredictionEngine {
  const PredictionEngine();

  FootballMatch buildMatch({
    required String id,
    required String league,
    required String home,
    required String away,
    required DateTime kickoff,
    int? fixtureId,
    int? leagueId,
    int? homeTeamId,
    int? awayTeamId,
  }) {
    final homeStrength = _teamStrength(home, bonus: 4);
    final awayStrength = _teamStrength(away, bonus: 0);
    final formDiff = homeStrength - awayStrength;
    final volatility = ((home.hashCode ^ away.hashCode).abs() % 18);
    final goalsScore = (68 + ((home.length + away.length + volatility) % 25)).clamp(55, 92);

    TipType tipType;
    String tipLabel;
    RiskLevel riskLevel;

    if (goalsScore >= 82 && formDiff.abs() <= 16) {
      tipType = TipType.over25;
      tipLabel = 'Über 2.5 Tore';
    } else if (goalsScore >= 79 && volatility >= 9) {
      tipType = TipType.bothTeamsScore;
      tipLabel = 'Beide Teams treffen';
    } else if (formDiff >= 12) {
      tipType = TipType.homeWin;
      tipLabel = 'Heimsieg';
    } else if (formDiff <= -12) {
      tipType = TipType.awayWin;
      tipLabel = 'Auswärtssieg';
    } else {
      tipType = TipType.doubleChance;
      tipLabel = formDiff >= 0 ? 'Doppelchance 1X' : 'Doppelchance X2';
    }

    final confidenceBase = 62 + (formDiff.abs() ~/ 2) + ((goalsScore - 65) ~/ 2);
    final aiScore = confidenceBase.clamp(50, 94).toInt();

    if (aiScore >= 82) {
      riskLevel = RiskLevel.low;
    } else if (aiScore >= 68) {
      riskLevel = RiskLevel.medium;
    } else {
      riskLevel = RiskLevel.high;
    }

    final odds = _syntheticOdds(tipType, aiScore, volatility);

    return FootballMatch(
      id: id,
      fixtureId: fixtureId,
      leagueId: leagueId,
      homeTeamId: homeTeamId,
      awayTeamId: awayTeamId,
      season: kickoff.year,
      league: league,
      homeTeam: home,
      awayTeam: away,
      kickoff: kickoff,
      kickoffLabel: kickoffLabel(kickoff),
      tipType: tipType,
      tipLabel: tipLabel,
      aiScore: aiScore,
      riskLevel: riskLevel,
      odds: odds,
      homeFormScore: homeStrength,
      awayFormScore: awayStrength,
      goalsScore: goalsScore,
      shortReason: _reason(tipType, homeStrength, awayStrength, goalsScore, aiScore),
    );
  }

  List<FootballMatch> rankTopTips(List<FootballMatch> matches, {int limit = 5}) {
    final copy = [...matches];
    copy.sort((a, b) => smartScore(b).compareTo(smartScore(a)));
    return copy.take(limit).toList();
  }

  int smartScore(FootballMatch match) {
    final ai = match.aiScore * 0.50;
    final oddsFit = _oddsFitScore(match.odds) * 0.20;
    final risk = _riskScore(match.riskLevel) * 0.20;
    final time = _timeScore(match.kickoff) * 0.10;
    return (ai + oddsFit + risk + time).round().clamp(0, 100);
  }

  int _teamStrength(String name, {required int bonus}) {
    final normalized = name.trim().toLowerCase();
    final chars = normalized.codeUnits.fold<int>(0, (sum, c) => sum + c);
    return (58 + bonus + (chars % 37)).clamp(45, 95);
  }

  double _syntheticOdds(TipType type, int aiScore, int volatility) {
    double base;
    switch (type) {
      case TipType.homeWin:
        base = 1.72;
        break;
      case TipType.awayWin:
        base = 1.92;
        break;
      case TipType.draw:
        base = 3.20;
        break;
      case TipType.doubleChance:
        base = 1.45;
        break;
      case TipType.over25:
        base = 1.78;
        break;
      case TipType.under25:
        base = 1.72;
        break;
      case TipType.bothTeamsScore:
        base = 1.82;
        break;
    }
    final modifier = ((100 - aiScore) / 100) + (volatility / 100);
    return double.parse((base + modifier).clamp(1.35, 2.95).toStringAsFixed(2));
  }

  int _oddsFitScore(double odds) {
    if (odds >= 1.50 && odds <= 2.30) return 100;
    if (odds >= 1.35 && odds <= 2.60) return 78;
    if (odds <= 3.00) return 55;
    return 35;
  }

  int _riskScore(RiskLevel risk) {
    switch (risk) {
      case RiskLevel.low:
        return 100;
      case RiskLevel.medium:
        return 72;
      case RiskLevel.high:
        return 35;
    }
  }

  int _timeScore(DateTime kickoff) {
    final hours = kickoff.difference(DateTime.now()).inHours;
    if (hours >= 2 && hours <= 24) return 100;
    if (hours > 24 && hours <= 48) return 75;
    if (hours >= 0) return 55;
    return 0;
  }

  String kickoffLabel(DateTime kickoff) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final matchDay = DateTime(kickoff.year, kickoff.month, kickoff.day);
    final diff = matchDay.difference(today).inDays;
    final time = '${kickoff.hour.toString().padLeft(2, '0')}:${kickoff.minute.toString().padLeft(2, '0')}';

    if (diff == 0) return 'Heute • $time';
    if (diff == 1) return 'Morgen • $time';
    if (diff == 2) return 'Übermorgen • $time';
    return '${kickoff.day.toString().padLeft(2, '0')}.${kickoff.month.toString().padLeft(2, '0')} • $time';
  }

  String _reason(TipType type, int homeScore, int awayScore, int goalsScore, int aiScore) {
    final edge = homeScore - awayScore;
    final base = 'KI-Score $aiScore · Heimform $homeScore · Auswärtsform $awayScore · Tortrend $goalsScore.';
    switch (type) {
      case TipType.homeWin:
        return '$base Heimteam mit Vorteil (+$edge).';
      case TipType.awayWin:
        return '$base Auswärtsteam mit Vorteil (${edge}).';
      case TipType.over25:
        return '$base Erhöhter Tortrend spricht für Über 2.5.';
      case TipType.bothTeamsScore:
        return '$base Beide Seiten mit offensiver Tendenz.';
      case TipType.doubleChance:
        return '$base Enges Spiel, daher Sicherheits-Tipp Doppelchance.';
      case TipType.draw:
      case TipType.under25:
        return base;
    }
  }
}
