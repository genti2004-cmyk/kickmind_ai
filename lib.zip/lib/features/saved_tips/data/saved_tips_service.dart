import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:kickmind_ai/features/matches/domain/football_match.dart';

class SavedTipsService {
  static const String _key = 'kickmind_saved_tips_v2';

  Future<List<FootballMatch>> loadSavedTips() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? <String>[];
    return raw
        .map((e) => jsonDecode(e))
        .whereType<Map<String, dynamic>>()
        .map(FootballMatch.fromJson)
        .toList();
  }

  Future<bool> isSaved(String matchId) async {
    final items = await loadSavedTips();
    return items.any((m) => m.id == matchId);
  }

  Future<void> saveTip(FootballMatch match) async {
    final prefs = await SharedPreferences.getInstance();
    final items = await loadSavedTips();
    final filtered = items.where((m) => m.id != match.id).toList()..insert(0, match);
    await prefs.setStringList(_key, filtered.map((e) => jsonEncode(e.toJson())).toList());
  }

  Future<void> removeTip(String matchId) async {
    final prefs = await SharedPreferences.getInstance();
    final items = await loadSavedTips();
    final filtered = items.where((m) => m.id != matchId).toList();
    await prefs.setStringList(_key, filtered.map((e) => jsonEncode(e.toJson())).toList());
  }
}
