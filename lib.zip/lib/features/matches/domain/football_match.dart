enum TipType {
  homeWin,
  awayWin,
  draw,
  doubleChance,
  over25,
  under25,
  bothTeamsScore,
}

enum RiskLevel { low, medium, high }

class FootballMatch {
  final String id;
  final int? fixtureId;
  final int? leagueId;
  final int? homeTeamId;
  final int? awayTeamId;
  final int season;
  final String league;
  final String homeTeam;
  final String awayTeam;
  final DateTime kickoff;
  final String kickoffLabel;
  final TipType tipType;
  final String tipLabel;
  final int aiScore;
  final RiskLevel riskLevel;
  final double odds;
  final int homeFormScore;
  final int awayFormScore;
  final int goalsScore;
  final String shortReason;

  const FootballMatch({
    required this.id,
    this.fixtureId,
    this.leagueId,
    this.homeTeamId,
    this.awayTeamId,
    required this.season,
    required this.league,
    required this.homeTeam,
    required this.awayTeam,
    required this.kickoff,
    required this.kickoffLabel,
    required this.tipType,
    required this.tipLabel,
    required this.aiScore,
    required this.riskLevel,
    required this.odds,
    required this.homeFormScore,
    required this.awayFormScore,
    required this.goalsScore,
    required this.shortReason,
  });

  String get riskLabel {
    switch (riskLevel) {
      case RiskLevel.low:
        return 'Niedrig';
      case RiskLevel.medium:
        return 'Mittel';
      case RiskLevel.high:
        return 'Hoch';
    }
  }

  String get riskEmoji {
    switch (riskLevel) {
      case RiskLevel.low:
        return '🟢';
      case RiskLevel.medium:
        return '🟡';
      case RiskLevel.high:
        return '🔴';
    }
  }

  bool get isStrongTip {
    return aiScore >= 78 && odds >= 1.45 && odds <= 2.60 && riskLevel != RiskLevel.high;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'fixtureId': fixtureId,
      'leagueId': leagueId,
      'homeTeamId': homeTeamId,
      'awayTeamId': awayTeamId,
      'season': season,
      'league': league,
      'homeTeam': homeTeam,
      'awayTeam': awayTeam,
      'kickoff': kickoff.toIso8601String(),
      'kickoffLabel': kickoffLabel,
      'tipType': tipType.name,
      'tipLabel': tipLabel,
      'aiScore': aiScore,
      'riskLevel': riskLevel.name,
      'odds': odds,
      'homeFormScore': homeFormScore,
      'awayFormScore': awayFormScore,
      'goalsScore': goalsScore,
      'shortReason': shortReason,
    };
  }

  factory FootballMatch.fromJson(Map<String, dynamic> json) {
    return FootballMatch(
      id: json['id']?.toString() ?? '',
      fixtureId: _intOrNull(json['fixtureId']),
      leagueId: _intOrNull(json['leagueId']),
      homeTeamId: _intOrNull(json['homeTeamId']),
      awayTeamId: _intOrNull(json['awayTeamId']),
      season: _intOrNull(json['season']) ?? DateTime.now().year,
      league: json['league']?.toString() ?? 'Soccer',
      homeTeam: json['homeTeam']?.toString() ?? 'Heimteam',
      awayTeam: json['awayTeam']?.toString() ?? 'Auswärtsteam',
      kickoff: DateTime.tryParse(json['kickoff']?.toString() ?? '') ?? DateTime.now(),
      kickoffLabel: json['kickoffLabel']?.toString() ?? '',
      tipType: _tipTypeFromName(json['tipType']?.toString()),
      tipLabel: json['tipLabel']?.toString() ?? 'Tipp',
      aiScore: _intOrNull(json['aiScore']) ?? 60,
      riskLevel: _riskLevelFromName(json['riskLevel']?.toString()),
      odds: _doubleOrDefault(json['odds'], 1.70),
      homeFormScore: _intOrNull(json['homeFormScore']) ?? 60,
      awayFormScore: _intOrNull(json['awayFormScore']) ?? 60,
      goalsScore: _intOrNull(json['goalsScore']) ?? 60,
      shortReason: json['shortReason']?.toString() ?? '',
    );
  }

  static int? _intOrNull(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    return int.tryParse(value.toString());
  }

  static double _doubleOrDefault(dynamic value, double fallback) {
    if (value == null) return fallback;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? fallback;
  }

  static TipType _tipTypeFromName(String? value) {
    return TipType.values.firstWhere(
          (e) => e.name == value,
      orElse: () => TipType.doubleChance,
    );
  }

  static RiskLevel _riskLevelFromName(String? value) {
    return RiskLevel.values.firstWhere(
          (e) => e.name == value,
      orElse: () => RiskLevel.medium,
    );
  }
}
