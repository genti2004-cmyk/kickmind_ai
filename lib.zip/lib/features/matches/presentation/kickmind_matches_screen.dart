import 'package:flutter/material.dart';

import '../data/api/football_api_service.dart';
import '../domain/football_match.dart';
import '../logic/prediction_engine.dart';
import 'package:kickmind_ai/features/saved_tips/data/saved_tips_service.dart';
import 'match_detail_screen.dart';

class KickMindMatchesScreen extends StatefulWidget {
  const KickMindMatchesScreen({super.key});

  @override
  State<KickMindMatchesScreen> createState() => _KickMindMatchesScreenState();
}

class _KickMindMatchesScreenState extends State<KickMindMatchesScreen> {
  final FootballApiService _api = FootballApiService();
  final PredictionEngine _engine = const PredictionEngine();
  late Future<List<FootballMatch>> _future;
  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _future = _api.fetchTodayFixtures();
  }

  void _refresh() {
    setState(() {
      _future = _api.fetchTodayFixtures(forceRefresh: true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FB),
      appBar: AppBar(
        title: const Text('KickMind AI'),
        centerTitle: false,
        elevation: 0,
        backgroundColor: const Color(0xFF0B5EA8),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'Aktualisieren',
            onPressed: _refresh,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: FutureBuilder<List<FootballMatch>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return _ErrorView(message: snapshot.error.toString(), onRetry: _refresh);
          }

          final matches = snapshot.data ?? const <FootballMatch>[];
          if (matches.isEmpty) {
            return _ErrorView(message: 'Keine Spiele gefunden.', onRetry: _refresh);
          }

          final pages = [
            _TodayPage(matches: matches),
            _TopTipsPage(matches: _engine.rankTopTips(matches, limit: 10), engine: _engine),
            _AnalysisPage(matches: matches, engine: _engine),
            const _SavedTipsPage(),
          ];

          return pages[_tabIndex];
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (value) => setState(() => _tabIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sports_soccer_rounded), label: 'Heute'),
          NavigationDestination(icon: Icon(Icons.auto_graph_rounded), label: 'Top Tipps'),
          NavigationDestination(icon: Icon(Icons.analytics_rounded), label: 'Analyse'),
          NavigationDestination(icon: Icon(Icons.bookmark_rounded), label: 'Meine Tipps'),
        ],
      ),
    );
  }
}

class _TodayPage extends StatelessWidget {
  final List<FootballMatch> matches;

  const _TodayPage({required this.matches});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      children: [
        _HeroHeader(
          title: 'Heute',
          subtitle: '${matches.length} Spiele geladen · TheSportsDB + lokale KI',
          icon: Icons.sports_soccer_rounded,
        ),
        const SizedBox(height: 14),
        ...matches.map((m) => _MatchCard(match: m)),
      ],
    );
  }
}

class _TopTipsPage extends StatelessWidget {
  final List<FootballMatch> matches;
  final PredictionEngine engine;

  const _TopTipsPage({required this.matches, required this.engine});

  @override
  Widget build(BuildContext context) {
    final strong = matches.where((m) => m.isStrongTip).toList();
    final display = strong.isEmpty ? matches.take(5).toList() : strong.take(5).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      children: [
        _HeroHeader(
          title: 'Top Tipps',
          subtitle: 'Smart Ranking aus Score, Quote, Risiko und Zeitnähe',
          icon: Icons.bolt_rounded,
        ),
        const SizedBox(height: 14),
        ...display.asMap().entries.map(
              (entry) => _TopTipCard(
            rank: entry.key + 1,
            match: entry.value,
            smartScore: engine.smartScore(entry.value),
          ),
        ),
      ],
    );
  }
}

class _AnalysisPage extends StatelessWidget {
  final List<FootballMatch> matches;
  final PredictionEngine engine;

  const _AnalysisPage({required this.matches, required this.engine});

  @override
  Widget build(BuildContext context) {
    final avgAi = matches.map((m) => m.aiScore).fold<int>(0, (a, b) => a + b) / matches.length;
    final strong = matches.where((m) => m.isStrongTip).length;
    final lowRisk = matches.where((m) => m.riskLevel == RiskLevel.low).length;
    final top = engine.rankTopTips(matches, limit: 3);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      children: [
        _HeroHeader(
          title: 'Analyse',
          subtitle: 'Übersicht der aktuellen Spiele und KI-Signale',
          icon: Icons.analytics_rounded,
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _MetricCard(label: 'Spiele', value: '${matches.length}')),
            const SizedBox(width: 10),
            Expanded(child: _MetricCard(label: 'Ø KI', value: avgAi.toStringAsFixed(0))),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _MetricCard(label: 'Starke Tipps', value: '$strong')),
            const SizedBox(width: 10),
            Expanded(child: _MetricCard(label: 'Niedrig Risiko', value: '$lowRisk')),
          ],
        ),
        const SizedBox(height: 16),
        const Text('Top 3 nach Smart Ranking', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        ...top.map((m) => _MatchCard(match: m, trailingLabel: 'Smart ${engine.smartScore(m)}')),
      ],
    );
  }
}

class _SavedTipsPage extends StatefulWidget {
  const _SavedTipsPage();

  @override
  State<_SavedTipsPage> createState() => _SavedTipsPageState();
}

class _SavedTipsPageState extends State<_SavedTipsPage> {
  final SavedTipsService _service = SavedTipsService();
  late Future<List<FootballMatch>> _future;

  @override
  void initState() {
    super.initState();
    _future = _service.loadSavedTips();
  }

  void _reload() {
    setState(() {
      _future = _service.loadSavedTips();
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<FootballMatch>>(
      future: _future,
      builder: (context, snapshot) {
        final items = snapshot.data ?? const <FootballMatch>[];
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
          children: [
            _HeroHeader(
              title: 'Meine Tipps',
              subtitle: '${items.length} gespeicherte Tipps',
              icon: Icons.bookmark_rounded,
            ),
            const SizedBox(height: 14),
            if (snapshot.connectionState == ConnectionState.waiting)
              const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
            else if (items.isEmpty)
              const _EmptyCard(text: 'Noch keine Tipps gespeichert. Öffne ein Spiel und tippe auf „Tipp speichern“.')
            else
              ...items.map(
                    (m) => _MatchCard(
                  match: m,
                  trailingLabel: 'Löschen',
                  onTrailingTap: () async {
                    await _service.removeTip(m.id);
                    _reload();
                  },
                ),
              ),
          ],
        );
      },
    );
  }
}

class _MatchCard extends StatelessWidget {
  final FootballMatch match;
  final String? trailingLabel;
  final VoidCallback? onTrailingTap;

  const _MatchCard({required this.match, this.trailingLabel, this.onTrailingTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shadowColor: Colors.black.withOpacity(0.08),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => MatchDetailScreen(match: match)),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      match.league,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF0B5EA8)),
                    ),
                  ),
                  Text(match.kickoffLabel, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                ],
              ),
              const SizedBox(height: 8),
              Text('${match.homeTeam}  vs  ${match.awayTeam}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _Chip(label: match.tipLabel, icon: Icons.tips_and_updates_rounded),
                  _Chip(label: 'KI ${match.aiScore}', icon: Icons.psychology_rounded),
                  _Chip(label: '${match.riskEmoji} ${match.riskLabel}', icon: Icons.security_rounded),
                  _Chip(label: 'Quote ${match.odds.toStringAsFixed(2)}', icon: Icons.euro_rounded),
                ],
              ),
              if (trailingLabel != null) ...[
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: onTrailingTap,
                    child: Text(trailingLabel!),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _TopTipCard extends StatelessWidget {
  final int rank;
  final FootballMatch match;
  final int smartScore;

  const _TopTipCard({required this.rank, required this.match, required this.smartScore});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 16, offset: const Offset(0, 8))],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => MatchDetailScreen(match: match))),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: const Color(0xFF0B5EA8),
                foregroundColor: Colors.white,
                child: Text('$rank', style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${match.homeTeam} vs ${match.awayTeam}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 5),
                    Text('${match.tipLabel} · KI ${match.aiScore} · Smart $smartScore', style: const TextStyle(color: Colors.black54)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeroHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;

  const _HeroHeader({required this.title, required this.subtitle, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0B5EA8), Color(0xFF1686D9)]),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 34),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.white70)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;

  const _MetricCard({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 14, offset: const Offset(0, 8))]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Color(0xFF0B5EA8))),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final IconData icon;

  const _Chip({required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: const Color(0xFFEAF3FB), borderRadius: BorderRadius.circular(999)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: const Color(0xFF0B5EA8)),
          const SizedBox(width: 5),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Color(0xFF0B5EA8))),
        ],
      ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final String text;

  const _EmptyCard({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: Text(text, style: const TextStyle(color: Colors.black54)),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.warning_amber_rounded, size: 48, color: Color(0xFF0B5EA8)),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: onRetry, child: const Text('Erneut laden')),
          ],
        ),
      ),
    );
  }
}
