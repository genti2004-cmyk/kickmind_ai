import 'package:flutter/material.dart';

import '../domain/football_match.dart';
import '../logic/prediction_engine.dart';
import 'package:kickmind_ai/features/saved_tips/data/saved_tips_service.dart';

class MatchDetailScreen extends StatefulWidget {
  final FootballMatch match;

  const MatchDetailScreen({super.key, required this.match});

  @override
  State<MatchDetailScreen> createState() => _MatchDetailScreenState();
}

class _MatchDetailScreenState extends State<MatchDetailScreen> {
  final SavedTipsService _savedTipsService = SavedTipsService();
  final PredictionEngine _engine = const PredictionEngine();
  bool _saved = false;
  double _stake = 10;

  @override
  void initState() {
    super.initState();
    _loadSavedState();
  }

  Future<void> _loadSavedState() async {
    final saved = await _savedTipsService.isSaved(widget.match.id);
    if (mounted) setState(() => _saved = saved);
  }

  Future<void> _toggleSaved() async {
    if (_saved) {
      await _savedTipsService.removeTip(widget.match.id);
    } else {
      await _savedTipsService.saveTip(widget.match);
    }
    if (!mounted) return;
    setState(() => _saved = !_saved);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_saved ? 'Tipp gespeichert' : 'Tipp entfernt')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final match = widget.match;
    final possibleReturn = _stake * match.odds;
    final profit = possibleReturn - _stake;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FB),
      appBar: AppBar(
        title: const Text('Spielanalyse'),
        backgroundColor: const Color(0xFF0B5EA8),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 26),
        children: [
          _Header(match: match),
          const SizedBox(height: 14),
          _SectionCard(
            title: 'KI-Prognose',
            child: Column(
              children: [
                _InfoRow(label: 'Empfohlener Tipp', value: match.tipLabel),
                _InfoRow(label: 'KI-Score', value: '${match.aiScore}/100'),
                _InfoRow(label: 'Smart Ranking', value: '${_engine.smartScore(match)}/100'),
                _InfoRow(label: 'Risiko', value: '${match.riskEmoji} ${match.riskLabel}'),
                _InfoRow(label: 'Quote', value: match.odds.toStringAsFixed(2)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Analysewerte',
            child: Column(
              children: [
                _ScoreBar(label: 'Heimform', value: match.homeFormScore),
                _ScoreBar(label: 'Auswärtsform', value: match.awayFormScore),
                _ScoreBar(label: 'Tortrend', value: match.goalsScore),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Begründung',
            child: Text(match.shortReason, style: const TextStyle(height: 1.35, color: Colors.black87)),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'Gewinnsimulation',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Einsatz: ${_stake.toStringAsFixed(0)} €', style: const TextStyle(fontWeight: FontWeight.w800)),
                Slider(
                  min: 5,
                  max: 100,
                  divisions: 19,
                  value: _stake,
                  onChanged: (value) => setState(() => _stake = value),
                ),
                _InfoRow(label: 'Mögliche Auszahlung', value: '${possibleReturn.toStringAsFixed(2)} €'),
                _InfoRow(label: 'Möglicher Gewinn', value: '${profit.toStringAsFixed(2)} €'),
              ],
            ),
          ),
          const SizedBox(height: 14),
          ElevatedButton.icon(
            onPressed: _toggleSaved,
            icon: Icon(_saved ? Icons.bookmark_remove_rounded : Icons.bookmark_add_rounded),
            label: Text(_saved ? 'Tipp entfernen' : 'Tipp speichern'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0B5EA8),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Hinweis: KickMind AI liefert nur Analyse- und Prognosewerte. Es gibt keine Gewinngarantie.',
            style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.3),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final FootballMatch match;

  const _Header({required this.match});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0B5EA8), Color(0xFF1686D9)]),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(match.league, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(
            '${match.homeTeam}\nvs\n${match.awayTeam}',
            style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, height: 1.16),
          ),
          const SizedBox(height: 12),
          Text(match.kickoffLabel, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 14, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _ScoreBar extends StatelessWidget {
  final String label;
  final int value;

  const _ScoreBar({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800))),
              Text('$value/100', style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF0B5EA8))),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              minHeight: 9,
              value: value.clamp(0, 100) / 100,
              backgroundColor: const Color(0xFFEAF3FB),
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF0B5EA8)),
            ),
          ),
        ],
      ),
    );
  }
}
