import 'dart:convert';
import 'package:http/http.dart' as http;

import '../../domain/football_match.dart';
import '../../logic/prediction_engine.dart';

class FootballApiService {
  FootballApiService({PredictionEngine? predictionEngine})
      : _predictionEngine = predictionEngine ?? const PredictionEngine();

  final PredictionEngine _predictionEngine;

  static List<FootballMatch>? _cache;
  static DateTime? _cacheTime;
  static Future<List<FootballMatch>>? _inFlightRequest;
  static const Duration _cacheDuration = Duration(minutes: 30);

  Future<List<FootballMatch>> fetchTodayFixtures({bool forceRefresh = false}) async {
    final now = DateTime.now();

    if (!forceRefresh && _cache != null && _cacheTime != null) {
      final age = now.difference(_cacheTime!);
      if (age < _cacheDuration) {
        return _cache!;
      }
    }

    if (!forceRefresh && _inFlightRequest != null) {
      return _inFlightRequest!;
    }

    _inFlightRequest = _loadAndCache(now);

    try {
      return await _inFlightRequest!;
    } finally {
      _inFlightRequest = null;
    }
  }

  Future<List<FootballMatch>> _loadAndCache(DateTime now) async {
    final matches = await _fetchFromSportsDb(now);
    final data = matches.isNotEmpty ? matches : _fallback();
    _saveCache(data);
    return data;
  }

  Future<List<FootballMatch>> _fetchFromSportsDb(DateTime now) async {
    try {
      final date = _formatDate(now);
      final uri = Uri.parse(
        'https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=$date&s=Soccer',
      );

      final response = await http.get(uri).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) return [];

      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) return [];

      final events = decoded['events'];
      if (events is! List || events.isEmpty) return [];

      final result = <FootballMatch>[];

      for (final raw in events) {
        if (raw is! Map<String, dynamic>) continue;

        final home = raw['strHomeTeam']?.toString().trim();
        final away = raw['strAwayTeam']?.toString().trim();
        if (home == null || home.isEmpty || away == null || away.isEmpty) continue;

        final league = raw['strLeague']?.toString().trim();
        final rawDate = raw['dateEventLocal']?.toString() ?? raw['dateEvent']?.toString() ?? date;
        final rawTime = raw['strTimeLocal']?.toString() ?? raw['strTime']?.toString() ?? '12:00:00';
        final kickoff = _parseKickoff(rawDate, rawTime, now);
        final localKickoff = kickoff.toLocal();

        if (!_isInTimeWindow(localKickoff, hours: 48)) continue;

        result.add(
          _predictionEngine.buildMatch(
            id: raw['idEvent']?.toString() ?? '${home}_$away_${localKickoff.millisecondsSinceEpoch}',
            fixtureId: int.tryParse(raw['idEvent']?.toString() ?? ''),
            league: league == null || league.isEmpty ? 'Soccer' : league,
            home: home,
            away: away,
            kickoff: localKickoff,
          ),
        );
      }

      result.sort((a, b) => a.kickoff.compareTo(b.kickoff));
      return result.take(40).toList();
    } catch (_) {
      return [];
    }
  }

  DateTime _parseKickoff(String rawDate, String rawTime, DateTime fallback) {
    final cleanTime = rawTime.replaceAll('Z', '').trim();
    final candidates = <String>[
      '${rawDate}T$cleanTime',
      '$rawDate $cleanTime',
      rawDate,
    ];

    for (final candidate in candidates) {
      final parsed = DateTime.tryParse(candidate);
      if (parsed != null) return parsed;
    }
    return fallback;
  }

  bool _isInTimeWindow(DateTime kickoff, {int hours = 48}) {
    final now = DateTime.now();
    return kickoff.isAfter(now.subtract(const Duration(hours: 2))) && kickoff.isBefore(now.add(Duration(hours: hours)));
  }

  void _saveCache(List<FootballMatch> data) {
    _cache = data;
    _cacheTime = DateTime.now();
  }

  String _formatDate(DateTime d) {
    return '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  List<FootballMatch> _fallback() {
    final now = DateTime.now();
    return [
      _predictionEngine.buildMatch(
        id: 'demo_1',
        league: 'Demo League',
        home: 'Team Alpha',
        away: 'Team Beta',
        kickoff: now.add(const Duration(hours: 2)),
      ),
      _predictionEngine.buildMatch(
        id: 'demo_2',
        league: 'Demo League',
        home: 'Team Gamma',
        away: 'Team Delta',
        kickoff: now.add(const Duration(hours: 5)),
      ),
      _predictionEngine.buildMatch(
        id: 'demo_3',
        league: 'Demo League',
        home: 'Team Nova',
        away: 'Team Orion',
        kickoff: now.add(const Duration(hours: 8)),
      ),
    ];
  }
}
